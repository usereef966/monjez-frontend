// src/components/Header.jsx
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import androidIcon from "../assets/svg/android-icon.svg";
import iosIcon     from "../assets/svg/ios-icon.svg";
import { Link } from "react-router-dom";


// ─── ثوابت الستايل ─────────────────────────────────────────────────────────────
const navBtnStyle = {
  padding: "6px 16px",
  borderRadius: 12,
  background: "#fff",
  color: "#444",
  fontWeight: 600,
  fontSize: 15,
  margin: "0 1px",
  textDecoration: "none",
  boxShadow: "0 2px 12px 0 rgba(124, 77, 255, 0.07)",
  border: "none",
  fontFamily: "Tajawal, Arial",
  transition: "all 0.18s",
  cursor: "pointer",
};

const navBtnStyleActive = {
  ...navBtnStyle,
  background: "linear-gradient(90deg,#7c4dff 60%,#a18fff 100%)",
  color: "#fff",
  boxShadow: "0 4px 16px 0 rgba(124, 77, 255, 0.18)",
};

const userBtnStyle = {
  padding: "10px 24px",
  borderRadius: 16,
  background: "#fff",
  color: "#7c4dff",
  fontWeight: 700,
  fontSize: 17,
  margin: "0 4px",
  textDecoration: "none",
  boxShadow: "0 4px 24px 0 rgba(124, 77, 255, 0.14)",
  border: "2px solid #e6dbff",
  fontFamily: "Tajawal, Arial",
  transition: "all 0.22s",
  cursor: "pointer",
};

// ─── بيانات القائمة المنسدلة مع المسارات ───────────────────────────────────────
const appOptions = [
  { label: "تطبيقات الأندرويد", icon: androidIcon, path: "/apps/android" },
  { label: "تطبيقات الآيفون",   icon: iosIcon,     path: "/apps/ios" },
];

// ─── 1) Dropdown الموبايل ───────────────────────────────────────────────────────
function MobileAppsDropdown() {
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();

  return (
    
    <div
      style={{ position: "relative", display: "inline-block", zIndex: 99 }}
      onMouseEnter={() => setOpen(true)}
      onMouseLeave={() => setOpen(false)}
    >
      <button
        onClick={e => e.preventDefault()}
        style={navBtnStyle}
      >
        تطبيقات الموبايل
        <span style={{ fontSize: 10, marginRight: 6, color: "#7c4dff" }}>▼</span>
      </button>

      {open && (
        <>
          {/* جسر شفاف */}
          <div
            style={{
              position: "absolute",
              top: "100%",
              right: 0,
              width: 210,
              height: 15,
              zIndex: 1000,
            }}
          />

          {/* القائمة */}
          <div
            style={{
              position: "absolute",
              top: "calc(100% + 8px)",
              right: 0,
              minWidth: 210,
              background: "#fff",
              borderRadius: 14,
              boxShadow: "0 14px 34px rgba(124,77,255,0.11)",
              padding: "10px 0",
              display: "flex",
              flexDirection: "column",
              gap: 2,
              textAlign: "right",
              zIndex: 9999,
            }}
          >
            {appOptions.map(({ label, icon, path }) => (
              <button
                key={path}
                onClick={() => {
                  navigate(path);
                  setOpen(false);
                }}
                style={{
                  background: "none",
                  border: "none",
                  width: "100%",
                  padding: "8px 16px",
                  display: "flex",
                  alignItems: "center",
                  gap: 10,
                  fontFamily: "Tajawal, Arial",
                  cursor: "pointer",
                  transition: ".14s",
                  borderRadius: 10,
                }}
                onMouseOver={e => (e.currentTarget.style.background = "#ede7fb")}
                onMouseOut={e => (e.currentTarget.style.background = "#fff")}
              >
                <img src={icon} alt={label} style={{ width: 20, height: 20 }} />
                <span style={{ color: "#444", fontSize: 15 }}>{label}</span>
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

// ─── 2) قوائم العضوية ───────────────────────────────────────────────────────────
function LoggedInMenu({ name }) {
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem('user');
    navigate('/login');
  };

  return (
    <div style={{ background: "#fff", borderRadius: 18, boxShadow: "0 8px 32px rgba(124,77,255,0.08)", padding: "6px 16px", display: "inline-flex", gap: 12, alignItems: "center" }}>
      <span style={{ color: "#333", fontWeight: 700, fontSize: 16 }}>
        {name}
      </span>
      <Link to="/orders" style={userBtnStyle}>طلباتي</Link>
      <Link to="/settings" style={userBtnStyle}>الإعدادات</Link>
      <button
        onClick={handleLogout}
        style={{ ...userBtnStyle, background: "#fff0f0", color: "#f44", border: "2px solid #ffd6d6" }}
      >
        تسجيل الخروج
      </button>
    </div>
  );
}
function LoggedOutMenu() {
  return (
   <div
  style={{
    background: "#fff",
    borderRadius: 18,
    boxShadow: "0 8px 32px rgba(124,77,255,0.08)",
    padding: "6px 16px",
    display: "inline-flex",
    gap: 12,
    alignItems: "center",
  }}
>
  <Link to="/login" style={userBtnStyle}>
    تسجيل الدخول
  </Link>
  <Link
    to="/register"
    style={{
      ...userBtnStyle,
      background: "#7c4dff",
      color: "#fff",
      border: "2px solid #a18fff",
    }}
  >
    تسجيل حساب
  </Link>
</div>

  );
}

// ─── 3) الكومبوننت الرئيسي ─────────────────────────────────────────────────────
export default function Header() {
  const user = JSON.parse(localStorage.getItem('user'));
const isLoggedIn = !!user;

  const navigate = useNavigate();


  return (
    
    <header
      style={{
        background: "#f8f8ff",
        padding: "0 0 32px",
        direction: "rtl",
        position: "relative",
      }}
    >
      {/* شعار المنصة */}
      <div style={{ position: "absolute", top: 17, left: 38, zIndex: 15 }}>
        <img src="/logo.svg" alt="شعار منجز" style={{ height: 38 }} />
      </div>

      {/* قوائم العضوية */}
      <div
        style={{
          position: "absolute",
          top: 18,
          right: 32,
          display: "flex",
          gap: 8,
          alignItems: "center",
          zIndex: 15,
        }}
      >
        {isLoggedIn ? <LoggedInMenu name={user?.name} /> : <LoggedOutMenu />}

      </div>

      {/* شريط التنقل */}
      <nav
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          gap: 20,
          padding: "18px 0 6px",
        }}
      >
           <button
          style={navBtnStyleActive}
          onClick={() => navigate("/")}
        >
          الصفحة الرئيسية
        </button>
        <MobileAppsDropdown />
        <button
  style={navBtnStyle}
  onClick={() => navigate("/seo")}
>
  تهيئة المواقع (SEO)
</button>
        <button
  style={navBtnStyle}
  onClick={() => navigate("/web")}
>
  برمجة المواقع
</button>
        <button
         onClick={() => navigate("/dev")}
         style={navBtnStyle}>تطوير الأنظمة</button>
        <button 
        onClick={() => navigate("/services")}
        style={navBtnStyle}>خدماتنا</button>
        <button
         onClick={() => navigate("/support")} 
        style={navBtnStyle}>من نحن</button>
         <button
         onClick={() => navigate("/plans")} 
        style={navBtnStyle}>الخطط والأسعار</button>
      </nav>

      {/* الرسم البياني السفلي */}
      <svg
        style={{ width: "100%", height: 220, marginTop: 50, display: "block" }}
        viewBox="0 0 1440 320"
        preserveAspectRatio="none"
      >
        <path
          d="M0,192 C350,320 1200,0 1440,160 L1440,0 L0,0 Z"
          fill="#a18fff"
        />
      </svg>

      {/* رسالة ترحيبية */}
      <div
        style={{
          textAlign: "center",
          marginTop: -80,
          position: "relative",
          zIndex: 5,
        }}
      >
        <h1
          style={{
            fontFamily: "Tajawal, Arial",
            fontWeight: "bold",
            fontSize: "2.5rem",
            color: "#23273c",
            marginBottom: 8,
          }}
        >
          أهلًا بك في منصة منجز
        </h1>
        <p style={{ color: "#666", fontSize: 18, fontFamily: "Tajawal, Arial" }}>
          الحل الأسرع لإنجاز المهام التقنية
        </p>
      </div>
    </header>
  );
}
