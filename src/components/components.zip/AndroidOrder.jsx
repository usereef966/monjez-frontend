import React, { useState } from "react";


// SVG IMPORTS
import storeIcon    from "../assets/svg/android-store.svg";
import eduIcon      from "../assets/svg/android-education.svg";
import healthIcon   from "../assets/svg/android-health.svg";
import chatIcon     from "../assets/svg/android-chat.svg";
import designIcon   from "../assets/svg/android-design.svg";
import financeIcon  from "../assets/svg/android-finance.svg";
import serviceIcon  from "../assets/svg/android-service.svg";
import ideaIcon     from "../assets/svg/idea.svg";
import shieldIcon   from "../assets/svg/saudi-shield.svg";
import checkIcon    from "../assets/svg/check.svg";
import launchIcon   from "../assets/svg/sa-launch.svg";
import supportIcon  from "../assets/svg/sa-support.svg";
import safeIcon     from "../assets/svg/sa-safe.svg";

const circles = [
  { key: "store",    label: "متجر إلكتروني",     icon: storeIcon },
  { key: "edu",      label: "تعليم وتدريب",       icon: eduIcon },
  { key: "health",   label: "صحة ولياقة",        icon: healthIcon },
  { key: "chat",     label: "دردشة وتواصل",      icon: chatIcon },
  { key: "design",   label: "تصاميم UI/UX",      icon: designIcon },
  { key: "finance",  label: "مال وأعمال",        icon: financeIcon },
  { key: "service",  label: "خدمات مخصصة",       icon: serviceIcon },
  { key: "idea",     label: "فكرة حرة",          icon: ideaIcon }
];

const badges = [
  {
    icon: launchIcon,
    title: "تسليم سريع",
    desc: "تطبيقك بين يديك خلال أيام بجودة سعودية وتوافق كامل."
  },
  {
    icon: supportIcon,
    title: "دعم فني سعودي",
    desc: "فريقنا معك خطوة بخطوة حتى بعد الإطلاق."
  },
  {
    icon: safeIcon,
    title: "حماية وأمان",
    desc: "بياناتك وتطبيقك تحت حماية تقنيات سعودية حديثة."
  }
];

export default function AndroidOrder() {
  const [selected, setSelected] = useState("store");
  const [idea, setIdea] = useState("");
  const [budget, setBudget] = useState("");
  const [audience, setAudience] = useState("");

 const siteTypeMap = {
  "متجر إلكتروني سعودي": 2,
  "تعليم وتدريب": 3,
  "صحة ولياقة": 1,
  "دردشة وتواصل": 4,
  "تصاميم UI/UX": 1,
  "مال وأعمال": 1,
  "خدمات مخصصة": 1,
  "فكرة حرة": 1
};


  const serviceLabel = circles.find(c => c.key === selected)?.label;
  const selectedSiteTypeId = siteTypeMap[serviceLabel] || 1;

 const budgetMap = {
  "5000-10000": 1,
  "10000-20000": 2,
  "20000+": 3
};


  const handleSubmit = async (e) => {
  e.preventDefault();

  const user = JSON.parse(localStorage.getItem("user"));
  if (!user?.id) return alert("يجب تسجيل الدخول أولًا");

  try {
    const res = await fetch("http://localhost:5000/api/orders/create-android", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
  user_id: user.id,
  site_type_id: selectedSiteTypeId,
  type: serviceLabel,
  section: "تطبيقات الجوال",
  platform: "Android",
  description: idea,
  notes: audience,
  budget_id: budgetMap[budget]

})
    });

    const data = await res.json();
    if (res.ok) {
      alert(data.message || "✅ تم إرسال الطلب!");
    } else {
      alert(data.error || "❌ حدث خطأ أثناء الإرسال.");
    }
  } catch {
    alert("⚠️ تعذر الاتصال بالخادم!");
  }
};



  return (

       
    <div style={{
      minHeight: "100vh",
      background: "linear-gradient(117deg, #e3fff0 70%, #e3eeff 100%)",
      position: "relative",
      paddingTop: 44, paddingBottom: 100,
      fontFamily: "Cairo, Tajawal, Arial",
      overflow: "hidden"
    }}>
      {/* العنوان */}
      <div style={{
        width: "100%",
        background: "linear-gradient(110deg, #a18fff 64%, #fff 100%)",
        height: 112,
        borderBottomLeftRadius: 54,
        borderBottomRightRadius: 84,
        boxShadow: "0 12px 44px #a18fff19",
        display: "flex",
        alignItems: "flex-end",
        justifyContent: "center"
      }}>
        <h1 style={{ color: "#222", fontWeight: 900, fontSize: 32, margin: 0, paddingBottom: 16 }}>
          اختر نوع التطبيق وابدأ رحلتك معنا
        </h1>
      </div>

      {/* الدوائر الكبيرة (صفين Grid) */}
      <div style={{
        display: "grid",
        gridTemplateColumns: "repeat(4, 1fr)",
        gap: 44,
        maxWidth: 970,
        margin: "55px auto 22px auto",
        justifyItems: "center"
      }}>
        {circles.map((c) => (
          <button
            key={c.key}
            className={`circle-card${selected === c.key ? " active" : ""}`}
            onClick={() => setSelected(c.key)}
            style={{
              width: 124,
              height: 124,
              background: "#fff",
              border: selected === c.key ? "4px solid #18e388" : "2px solid #d4ffe9",
              borderRadius: "50%",
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              boxShadow: selected === c.key
                ? "0 0 0 10px #18e38832, 0 6px 36px #24d3ad15"
                : "0 3px 18px #21e5a422",
              fontWeight: 900,
              cursor: "pointer",
              transition: "all .22s cubic-bezier(.4,2.1,.4,1)",
              filter: selected === c.key ? "drop-shadow(0 8px 32px #18e38833)" : ""
            }}
          >
            <img
              src={c.icon}
              alt={c.label}
              style={{
                width: 53,
                height: 53,
                marginBottom: 10,
                filter: selected === c.key
                  ? "drop-shadow(0 4px 16px #19ca8955)"
                  : "drop-shadow(0 2px 10px #baffd944)",
                transition: "all .19s"
              }}
            />
            <span style={{
              color: "#21c692",
              fontWeight: 900,
              fontSize: 17,
              marginTop: 1,
              letterSpacing: ".2px"
            }}>
              {c.label}
            </span>
          </button>
        ))}
      </div>

      {/* مربع الطلب الكبير */}
      <form
        className="order-form"
        style={{
          background: "#fff",
          borderRadius: 28,
          boxShadow: "0 7px 30px #18e38822, 0 2px 6px #23e38a10",
          maxWidth: 520,
          margin: "0 auto",
          padding: "36px 32px 26px",
          marginTop: 25,
          display: "flex",
          flexDirection: "column",
          gap: 22,
          fontFamily: "Cairo, Tajawal, Arial",
          zIndex: 2,
          alignItems: "center"
        }}
        onSubmit={handleSubmit}

      >
        <div style={{
          display: "flex",
          alignItems: "center",
          gap: 13,
          marginBottom: 10
        }}>
          <img src={serviceIcon} alt="نوع الخدمة" style={{ width: 38, height: 38, marginBottom: 0 }} />
          <h2 style={{
            color: "#19ca89",
            textAlign: "center",
            fontWeight: 900,
            fontSize: 23,
            margin: 0
          }}>
            {serviceLabel}
          </h2>
        </div>
        <input
          type="text"
          placeholder="فكرة التطبيق أو اسم المشروع"
          value={idea}
          onChange={e => setIdea(e.target.value)}
          required
          style={{
            padding: "13px 16px",
            borderRadius: 12,
            border: "1.8px solid #19ca8955",
            fontSize: 17,
            width: "100%"
          }}
        />
       <select
  value={budget}
  onChange={e => setBudget(e.target.value)}
  required
  style={{
    padding: "10px 12px",
    borderRadius: 13,
    border: "1.5px solid #ccc",
    fontSize: 16,
    width: "100%",
    background: "#fff",
    color: "#444",
    marginBottom: 15
  }}
>
  <option value="">الميزانية المتوقعة</option>
  <option value="5000-10000">5000 - 10000 ريال</option>
  <option value="10000-20000">10000 - 20000 ريال</option>
  <option value="20000+">أكثر من 20000 ريال</option>
</select>

        <input
          type="text"
          placeholder="الجمهور المستهدف (اختياري)"
          value={audience}
          onChange={e => setAudience(e.target.value)}
          style={{
            padding: "13px 16px",
            borderRadius: 12,
            border: "1.6px solid #19ca8955",
            fontSize: 16,
            width: "100%"
          }}
        />
        <button type="submit" style={{
          marginTop: 10,
          background: "linear-gradient(93deg,#17fd7b 50%,#3ae371 100%)",
          color: "#fff", fontWeight: 900, fontSize: 18,
          borderRadius: 13, border: "none",
          boxShadow: "0 6px 18px #18e38838",
          padding: "14px 0", letterSpacing: 0.5,
          cursor: "pointer", transition: "background .18s",
          width: "100%"
        }}>
          أرسل الطلب 🚀
        </button>
      </form>

      {/* كروت تحفيز/شهادات فاخرة */}
      <div style={{
        display: "flex",
        justifyContent: "center",
        gap: 33,
        margin: "50px auto 0 auto",
        maxWidth: 970,
        flexWrap: "wrap"
      }}>
        {badges.map((b, i) => (
          <div key={i} style={{
            background: "#fff",
            borderRadius: 20,
            minWidth: 215,
            maxWidth: 270,
            padding: "23px 20px 18px 20px",
            boxShadow: `0 8px 36px ${i === 0 ? "#21e5a418" : i === 1 ? "#738cff26" : "#e6ad4e1b"}`,
            borderBottom: `4.3px solid ${i === 0 ? "#17e388" : i === 1 ? "#6b79f3" : "#e6ad4e"}`,
            textAlign: "center",
            marginBottom: 14
          }}>
            <img src={b.icon} alt={b.title} style={{ width: 36, height: 36, marginBottom: 7 }} />
            <div style={{ fontWeight: 900, fontSize: 17.5, margin: "7px 0", color: i === 0 ? "#19ca89" : i === 1 ? "#6270e4" : "#d59a27" }}>
              {b.title}
            </div>
            <div style={{ color: "#444", fontSize: 14.8, fontWeight: 500 }}>{b.desc}</div>
          </div>
        ))}
      </div>

      {/* شريط توثيق سعودي */}
      <div style={{
  margin: "38px auto 0 auto",
  maxWidth: 540,
  padding: "14px 21px",
  background: "#f8fff7",
  border: "2.3px solid #21c69255",
  borderRadius: 18,
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  gap: 13,
  boxShadow: "0 3px 15px #b2ffd229"
}}>
        <img src={shieldIcon} alt="ختم سعودي" style={{ width: 31, height: 31 }} />
        <span style={{
          color: "#19ca89",
          fontWeight: 900,
          fontSize: 16.5,
          letterSpacing: 1.1,
          display: "flex",
          alignItems: "center"
        }}>
          جميع الطلبات تحت إشراف سعودي 100%
          <img src={checkIcon} alt="توثيق" style={{ height: 22, marginRight: 9, marginLeft: 4 }} />
        </span>
      </div>

      <style>
        {`
          .circle-card:hover, .circle-card.active {
            filter: drop-shadow(0 12px 32px #27e5a868);
            z-index: 20 !important;
            background: #f3fff9 !important;
          }
        `}
      </style>
    </div>
  
  );
}
