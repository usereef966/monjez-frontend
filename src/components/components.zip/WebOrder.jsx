import React, { useState, useEffect } from "react";
import { useLocation } from "react-router-dom";

// أيقونات
import shopIcon       from "../assets/svg/shop.svg";
import companyIcon    from "../assets/svg/company.svg";
import blogIcon       from "../assets/svg/blog.svg";
import platformIcon   from "../assets/svg/platform.svg";
import portfolioIcon  from "../assets/svg/portfolio.svg";
import landingIcon    from "../assets/svg/landing.svg";
import servicesIcon   from "../assets/svg/services.svg";
import chatIcon       from "../assets/svg/chat3.svg";

export default function WebOrder() {
  const [type, setType]               = useState("");
  const [desc, setDesc]               = useState("");
  const [budget, setBudget]           = useState("");
  const [featureOptions, setFeatureOptions] = useState([]);
  const [features, setFeatures]       = useState([]);

  const location = useLocation();

  useEffect(() => {
    async function loadFeatures() {
      try {
        const res = await fetch("http://localhost:5000/api/extra_features");
        if (res.ok) {
          const data = await res.json();
          setFeatureOptions(data);
        } else {
          console.error("Failed to fetch features", await res.text());
        }
      } catch (err) {
        console.error(err);
      }
    }
    loadFeatures();
  }, []);

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const siteTypeParam = params.get("type");
    if (siteTypeParam) {
      const typeMap = {
        "متجر إلكتروني":  "shop",
        "موقع شركة":      "company",
        "مدونة/موسوعة":   "blog",
        "منصة تعليمية":    "platform",
        "بورتفوليو":       "portfolio",
        "صفحة هبوط":       "landing",
        "موقع خدمات":      "services",
        "تطبيق دردشة":     "chat"
      };
      setType(typeMap[siteTypeParam] || "");
    }
  }, [location]);

  const toggleFeature = id => {
    setFeatures(prev =>
      prev.includes(id)
        ? prev.filter(f => f !== id)
        : [...prev, id]
    );
  };

  const handleSubmit = async () => {
    const user = JSON.parse(localStorage.getItem("user"));
    if (!user?.id) {
      alert("🔑 يجب تسجيل الدخول أولًا!");
      return;
    }
    try {
      const typeIdMap = {
        shop:      1,
        company:   2,
        blog:      3,
        platform:  4,
        portfolio: 5,
        landing:   6,
        services:  7,
        chat:      8
      };
      const payload = { 
        user_id:      user.id,
        description:  desc,   
        site_type_id: typeIdMap[type] || null,
        budget_id:    budget,
        feature_ids:  features
      };
      const res = await fetch("http://localhost:5000/api/orders", {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify(payload)
      });
      const result = await res.json();
      if (res.ok) {
        alert("✅ تم إرسال طلبك بنجاح!");
        setType("");
        setDesc("");
        setBudget("");
        setFeatures([]);
      } else {
        alert(result.error || "❌ حدث خطأ أثناء إرسال الطلب");
      }
    } catch {
      alert("⚠️ تعذر الاتصال بالخادم");
    }
  };

  const siteTypeOptions = [
    { key: "shop",      label: "متجر إلكتروني", icon: shopIcon },
    { key: "company",   label: "موقع شركة",     icon: companyIcon },
    { key: "blog",      label: "مدونة/موسوعة",  icon: blogIcon },
    { key: "platform",  label: "منصة تعليمية",   icon: platformIcon },
    { key: "portfolio", label: "بورتفوليو",      icon: portfolioIcon },
    { key: "landing",   label: "صفحة هبوط",      icon: landingIcon },
    { key: "services",  label: "موقع خدمات",     icon: servicesIcon },
    { key: "chat",      label: "تطبيق دردشة",    icon: chatIcon }
  ];

  const currentTypeLabel =
    siteTypeOptions.find(opt => opt.key === type)?.label || "—";

  const budgetMap = {
    1: "5,000 – 10,000 ريال",
    2: "10,000 – 20,000 ريال",
    3: "أكثر من 20,000 ريال"
  };

  return (
    <div style={{
      minHeight: "100vh",
      background: "#F7F8FF",
      fontFamily: "Tajawal, Arial",
      direction: "rtl",
      padding: 0
    }}>
      <div style={{
        width: "100%",
        minHeight: 150,
        background: "linear-gradient(97deg,#7c4dff 55%,#24e6ca 100%)",
        borderBottomLeftRadius: 44,
        borderBottomRightRadius: 80,
        boxShadow: "0 16px 48px #7c4dff14",
        textAlign: "center",
        padding: "40px 0"
      }}>
        <h1 style={{
          color: "#fff",
          fontWeight: 900,
          fontSize: 36,
          letterSpacing: ".7px",
          margin: 0
        }}>
          🚀 اطلب برمجة موقعك — كل شيء ديناميكي!
        </h1>
        <p style={{
          color: "#d7fffa",
          fontSize: 19,
          fontWeight: 700,
          margin: "8px 0 0"
        }}>
          صمم فكرتك بنفسك… ثم أرسلها فوراً بنظام تفاعلي لم تشاهده من قبل!
        </p>
      </div>

      <div style={{
        maxWidth: 1200,
        margin: "0 auto",
        padding: "36px 20px",
        display: "flex",
        gap: 40,
        alignItems: "flex-start"
      }}>
        {/* اختيار نوع الموقع */}
        <div style={{
          flex: "0 0 330px",
          background: "#fff",
          borderRadius: 21,
          boxShadow: "0 7px 24px #a18fff13",
          border: "2px solid #e7e3ff",
          padding: "36px 30px",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          gap: 18
        }}>
          <div style={{
            color: "#7c4dff",
            fontWeight: 900,
            fontSize: 19,
            marginBottom: 14
          }}>اختر نوع الموقع:</div>
          <div style={{
            display: "grid",
            gridTemplateColumns: "1fr 1fr",
            gap: 15
          }}>
            {siteTypeOptions.map(opt => (
              <button
                key={opt.key}
                onClick={() => setType(opt.key)}
                style={{
                  background: type === opt.key
                    ? "linear-gradient(93deg,#24e6ca 40%,#7c4dff 100%)"
                    : "#f6faff",
                  border: type === opt.key
                    ? "2px solid #21c692"
                    : "1.6px solid #ececff",
                  color: type === opt.key ? "#fff" : "#222",
                  borderRadius: 13,
                  fontWeight: 900,
                  fontSize: 16,
                  padding: "22px 14px",
                  display: "flex",
                  flexDirection: "column",
                }}
              >
                <img src={opt.icon} alt="" style={{ width: 36, marginBottom: 5 }} />
                {opt.label}
              </button>
            ))}
          </div>
        </div>

        {/* وصف المشروع + مميزات + الميزانية + إرسال */}
        <div style={{
          flex: 1,
          background: "#fff",
          borderRadius: 21,
          boxShadow: "0 7px 24px #a18fff13",
          border: "2px solid #e7e3ff",
          padding: "38px 38px 32px",
          display: "flex",
          flexDirection: "column",
          gap: 22
        }}>
          <div style={{ fontWeight: 900, color: "#23273c", fontSize: 19 }}>
            فكرة مشروعك أو وصف مختصر:
          </div>
          <textarea
            value={desc}
            onChange={e => setDesc(e.target.value)}
            rows={5}
            placeholder="مثال: متجر إلكتروني عصري لبيع منتجات…"
            style={{
              width: "100%",
              borderRadius: 12,
              border: "1.6px solid #ececff",
              fontSize: 17,
              padding: "18px 17px",
              background: "#f8f7fd"
            }}
          />

          <div style={{ display: "flex", gap: 40, marginTop: 20 }}>
            {/* المميزات */}
            <div style={{
              flex: "0 0 330px",
              background: "#fff",
              borderRadius: 21,
              boxShadow: "0 7px 24px #24e6ca13",
              border: "2px solid #e7e3ff",
              padding: "32px 28px",
              display: "flex",
              flexDirection: "column",
              gap: 20
            }}>
              <div style={{ color: "#21c692", fontWeight: 900, fontSize: 18 }}>
                المميزات الإضافية:
              </div>
              {featureOptions.map(f => (
                <label key={f.id} style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 7,
                  fontWeight: 800
                }}>
                  <input
                    type="checkbox"
                    checked={features.includes(f.id)}
                    onChange={() => toggleFeature(f.id)}
                  />
                  {f.name}
                </label>
              ))}

              {/* الميزانية */}
              <div style={{ marginTop: 28 }}>
                <div style={{
                  fontWeight: 900,
                  color: "#7c4dff",
                  marginBottom: 8
                }}>اختر ميزانية:</div>
                <select
                  value={budget}
                  onChange={e => setBudget(parseInt(e.target.value))}
                  style={{
                    width: "100%",
                    borderRadius: 11,
                    border: "1.4px solid #e1deff",
                    fontSize: 16,
                    fontWeight: 800,
                    padding: "10px 13px"
                  }}
                >
                  <option value="">اختر...</option>
                  <option value={1}>5,000 – 10,000 ريال</option>
                  <option value={2}>10,000 – 20,000 ريال</option>
                  <option value={3}>أكثر من 20,000 ريال</option>
                </select>
              </div>
            </div>

            {/* معاينة + إرسال */}
            <div style={{
              flex: 1,
              background: "#f8f7fd",
              borderRadius: 21,
              boxShadow: "0 7px 24px #a18fff13",
              border: "2px solid #e7e3ff",
              padding: "33px",
              display: "flex",
              flexDirection: "column",
              gap: 19,
              alignItems: "center"
            }}>
              <div style={{ fontWeight: 900, color: "#7c4dff", fontSize: 19 }}>
                معاينة Live — ملخص طلبك:
              </div>
              <div style={{
                background: "#fff",
                borderRadius: 16,
                padding: "23px 19px",
                boxShadow: "0 4px 18px #7c4dff08",
                width: "100%",
                maxWidth: 380,
                textAlign: "right"
              }}>
                <div>نوع الموقع: <span style={{ color: "#23273c", marginLeft: 5 }}>{currentTypeLabel}</span></div>
                <div>وصف المشروع: <span style={{ color: "#23273c", marginLeft: 5 }}>{desc || "—"}</span></div>
                <div>المميزات:
                  <div style={{ marginTop: 5 }}>
                    {features.length
                      ? features.map((id, i) => (
                          <div key={i} style={{ color: "#23273c" }}>
                            ✅ {featureOptions.find(f => f.id === id)?.name}
                          </div>
                        ))
                      : "—"}
                  </div>
                </div>
                <div>الميزانية: <span style={{ color: "#7c4dff", marginLeft: 5 }}>{budgetMap[budget] || "—"}</span></div>
              </div>
              <button
                onClick={handleSubmit}
                style={{
                  marginTop: 18,
                  padding: "15px 0",
                  width: 240,
                  borderRadius: 14,
                  background: "linear-gradient(93deg,#7c4dff 55%,#24e6ca 100%)",
                  color: "#fff",
                  fontWeight: 900,
                  fontSize: 20,
                  border: "none",
                  cursor: "pointer"
                }}
              >
                أرسل الطلب الآن 🚀
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
