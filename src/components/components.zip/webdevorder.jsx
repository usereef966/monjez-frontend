import React, { useState } from "react";
// SVGs icons
import storeIcon from "../assets/svg/store.svg";
import eduIcon from "../assets/svg/edu.svg";
import healthIcon from "../assets/svg/health.svg";
import chatIcon from "../assets/svg/chat3.svg";
import uiuxIcon from "../assets/svg/uiux.svg";
import businessIcon from "../assets/svg/business.svg";
import customIcon from "../assets/svg/custom.svg";
import ideaIcon from "../assets/svg/idea.svg";

const services = [
  { icon: storeIcon, label: "متجر إلكتروني" },
  { icon: eduIcon, label: "تعليم وتدريب" },
  { icon: healthIcon, label: "صحة ولياقة" },
  { icon: chatIcon, label: "دردشة وتواصل" },
  { icon: uiuxIcon, label: "تصميم UI/UX" },
  { icon: businessIcon, label: "مال وأعمال" },
  { icon: customIcon, label: "خدمات مخصصة" },
  { icon: ideaIcon, label: "فكرة جديدة" }
];

export default function OrderPage() {
  const [selected, setSelected] = useState(0);

  return (
    <div
      dir="rtl"
      style={{
        minHeight: "100vh",
        width: "100vw",
        background: "linear-gradient(135deg, #e6f3ff 0%, #e5e8ff 65%, #e5fff7 100%)",
        overflow: "hidden",
        fontFamily: "Tajawal, Arial, sans-serif",
        position: "relative"
      }}
    >
      {/* موجة هيدر تغطي كل العرض */}
      <div style={{ position: "relative", width: "100%", minHeight: 220, zIndex: 2 }}>
       
        <div style={{
          position: "relative",
          width: "100%",
          textAlign: "center",
          zIndex: 3,
          paddingTop: 52
        }}>
          <h2 style={{
            fontSize: 40, fontWeight: 900, color: "#fff",
            textShadow: "0 4px 24px #7c4dffbb,0 1px 2px #24e9ca99",
            margin: 0, letterSpacing: ".03em", lineHeight: "58px"
          }}>
            اختر نوع التطبيق وابدأ رحلتك معنا 🚀
          </h2>
        </div>
      </div>

      {/* Grid صفين وسط الصفحة */}
      <div style={{
        display: "grid",
        gridTemplateColumns: "repeat(4, 1fr)",
        gap: 32,
        maxWidth: 950,
        margin: "0 auto",
        marginTop: -80,
        marginBottom: 45,
        zIndex: 10
      }}>
        {services.map((item, i) => (
          <div key={i}
            tabIndex={0}
            onClick={() => setSelected(i)}
            style={{
              background: selected === i ? "#e9f0ff" : "#fff",
              borderRadius: 26,
              boxShadow: selected === i ? "0 8px 24px #7c4dff14" : "0 2px 8px #c1e1ff11",
              border: selected === i ? "2.5px solid #7c4dff" : "2.2px solid #e4e6fc",
              display: "flex", flexDirection: "column", alignItems: "center",
              justifyContent: "center", cursor: "pointer",
              padding: "33px 0 18px 0", minWidth: 120, minHeight: 124,
              transition: "all .19s",
              fontWeight: 700
            }}
          >
            <img src={item.icon} alt={item.label} style={{
              width: 36, height: 36, marginBottom: 11,
              filter: selected === i ? "drop-shadow(0 3px 9px #7c4dff55)" : "none",
              transition: "all .16s"
            }} />
            <div style={{
              color: "#5e5a99",
              fontWeight: 800,
              fontSize: 17,
              textAlign: "center",
              letterSpacing: ".01em"
            }}>{item.label}</div>
          </div>
        ))}
      </div>

      {/* النموذج في النص */}
      <div style={{
        background: "linear-gradient(120deg,#fff,#f3fcff 95%)",
        borderRadius: 29,
        boxShadow: "0 8px 32px #a488fa13,0 2px 10px #7c4dff09",
        border: "2.2px solid #e5e2fc",
        padding: "36px 28px 26px 28px",
        margin: "0 auto",
        maxWidth: 420,
        position: "relative",
        zIndex: 12,
        minHeight: 220,
        marginBottom: 40
      }}>
        <div style={{
          fontWeight: 900, fontSize: 22, color: "#8247e5", marginBottom: 15, textAlign: "center"
        }}>
          {services[selected].label}
        </div>
        <input
          placeholder="فكرة التطبيق أو اسم المشروع"
          style={{
            width: "100%", borderRadius: 12, border: "2px solid #ece8fb",
            background: "#f7f6ff", padding: "13px", fontWeight: 600,
            color: "#5e5a99", fontSize: 15, marginBottom: 13
          }}
        />
        <input
          placeholder="ميزانية متوقعة (اختياري)"
          style={{
            width: "100%", borderRadius: 12, border: "2px solid #ece8fb",
            background: "#f7f6ff", padding: "13px", fontWeight: 600,
            color: "#5e5a99", fontSize: 15, marginBottom: 13
          }}
        />
        <textarea
          placeholder="تفاصيل أو شروط/ملف (اختياري)"
          rows={2}
          style={{
            width: "100%", borderRadius: 11, border: "2px solid #ece8fb",
            fontSize: 15, color: "#5e5a99", fontWeight: 600,
            marginBottom: 12, background: "#f7f6ff", padding: 11, outline: "none"
          }}
        />
        <button
          style={{
            width: "100%", padding: "13px", borderRadius: 15,
            background: "linear-gradient(90deg,#7c4dff 40%,#22e0fd 120%)",
            color: "#fff", fontWeight: 900, fontSize: 19,
            border: "none", outline: "none", boxShadow: "0 3px 20px #7c4dff23",
            cursor: "pointer", transition: "all .16s", letterSpacing: ".02em"
          }}
        >
          أرسل الطلب الآن 🚀
        </button>
      </div>

      {/* الميزات السفلية (Features) */}
      <div style={{
        display: "flex", justifyContent: "center", gap: 28, marginTop: 10, marginBottom: 18, flexWrap: "wrap"
      }}>
        {/* ...نفس كروت الميزات، أضف أو عدل كما تحب */}
      </div>

      {/* خط سفلي للتحفيز */}
      <div style={{
        margin: "18px auto 11px", color: "#25b358", fontSize: 18, fontWeight: 700, textAlign: "center"
      }}>
        ✔️ جميع الطلبات تحت إشراف سعودي 100%
      </div>
    </div>
  );
}
