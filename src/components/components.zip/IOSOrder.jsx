import React, { useState } from "react";
import { useLocation } from "react-router-dom";

// استيراد الأيقونات
import appleIcon    from "../assets/svg/apple-logo.svg";
import shopIcon     from "../assets/svg/ios-store.svg";
import eduIcon      from "../assets/svg/ios-education.svg";
import healthIcon   from "../assets/svg/ios-health.svg";
import chatIcon     from "../assets/svg/ios-chat.svg";
import designIcon   from "../assets/svg/ios-design.svg";
import financeIcon  from "../assets/svg/ios-finance.svg";
import serviceIcon  from "../assets/svg/ios-service.svg";
import ideaIcon     from "../assets/svg/idea.svg";

import badgeMedal   from "../assets/svg/ios-medal.svg";
import badgeSafe    from "../assets/svg/ios-safe.svg";
import badgeSupport from "../assets/svg/ios-support.svg";
import shieldIcon   from "../assets/svg/apple-shield.svg";
import checkIcon    from "../assets/svg/check.svg";

const cards = [
  { key: "shop",    label: "متجر آيفون",   icon: shopIcon },
  { key: "edu",     label: "تعليم ذكي",    icon: eduIcon },
  { key: "health",  label: "صحة ولياقة",   icon: healthIcon },
  { key: "chat",    label: "دردشة فاخرة",  icon: chatIcon },
  { key: "design",  label: "تصاميم Apple", icon: designIcon },
  { key: "finance", label: "مال وأعمال",   icon: financeIcon },
  { key: "service", label: "خدمات أعمال",  icon: serviceIcon },
  { key: "idea",    label: "فكرة حرة",     icon: ideaIcon }
];



const badges = [
  {
    icon: badgeMedal,
    title: "جودة Apple",
    desc: "تجربة مستخدم فاخرة بأدق التفاصيل."
  },
  {
    icon: badgeSupport,
    title: "دعم فني متواصل",
    desc: "فريق متخصص لخدمتك من البداية للنهاية."
  },
  {
    icon: badgeSafe,
    title: "حماية بياناتك",
    desc: "خصوصيتك محفوظة بتقنيات أمان متقدمة."
  }
];

export default function IOSOrder() {
  const [selected,   setSelected]   = useState("shop");
  const [idea,       setIdea]       = useState("");
  const [budget,     setBudget]     = useState("");
  const [audience,   setAudience]   = useState("");

  const location = useLocation();
  const params   = new URLSearchParams(location.search);
  const typeFromURL = params.get("type");

  // تعريف الخدمة المختارة
  const selectedCard = cards.find(c => c.key === selected) || {};
  const serviceLabel = selectedCard.label;
  const serviceIcon  = selectedCard.icon;

  const siteTypeMap = {
    "متجر آيفون": 2,
    "تعليم ذكي":  3,
    "صحة ولياقة": 1,
    "دردشة فاخرة": 4,
    "تصاميم Apple": 1,
    "مال وأعمال":  1,
    "خدمات أعمال": 1,
    "فكرة حرة":    1
  };
  const selectedSiteTypeId = siteTypeMap[serviceLabel] || 1;

  const budgetMap = {
  "5000-10000": 1,
  "10000-20000": 2,
  "20000+": 3
};


  const handleSubmit = async e => {
    e.preventDefault();
    const user = JSON.parse(localStorage.getItem("user"));
    if (!user?.id) {
      alert("يجب تسجيل الدخول أولًا");
      
      return;

      
    }

    console.log("🚀 البيانات المرسلة:", {
  user_id:      user.id,
  site_type_id: selectedSiteTypeId,
  type:         serviceLabel,
  section:      "تطبيقات الجوال",
  platform:     "iOS",
  description:  idea,
  notes:        audience,
  budget_id:    budgetMap[budget]
});
    try {
      const res = await fetch(
        "http://localhost:5000/api/orders/create-ios",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            user_id:      user.id,
            site_type_id: selectedSiteTypeId,
            type:         serviceLabel,
            section:      "تطبيقات الجوال",
            platform:     "iOS",
            description:  idea,
            notes:        audience,
            budget_id: budgetMap[budget]

          })
        }
      );
      const data = await res.json();
      alert(
        res.ok
          ? data.message || "✅ تم إرسال الطلب!"
          : data.error   || "❌ حدث خطأ أثناء الإرسال."
      );
    } catch {
      alert("⚠️ تعذر الاتصال بالخادم!");
    }
  };

  return (
    <div style={{
      minHeight: "100vh",
      background: "linear-gradient(110deg, #edefff 80%, #e6f0fa 100%)",
      position: "relative",
      paddingTop: 48,
      paddingBottom: 90,
      fontFamily: "San Francisco, Tajawal, Arial",
      overflow: "hidden"
    }}>
      {/* الهيدر */}
      <div style={{
        width: "100%",
        background: "linear-gradient(115deg, #b6c1ff 60%, #e8eafd 100%)",
        height: 115,
        borderBottomLeftRadius: 60,
        borderBottomRightRadius: 120,
        boxShadow: "0 10px 42px #b6c1ff22",
        display: "flex",
        alignItems: "flex-end",
        justifyContent: "center"
      }}>
        <img src={appleIcon} alt="Apple" style={{ width: 56, marginRight: 18 }} />
        <h1 style={{
          color: "#525dcb",
          fontWeight: 900,
          fontSize: 29,
          margin: 0,
          paddingBottom: 13
        }}>
          عالم تطبيقات iOS الفاخر
        </h1>
      </div>

      {/* نص إرشادي */}
      <div style={{
        textAlign: "center",
        color: "#6a70c8",
        fontWeight: 800,
        fontSize: 19,
        margin: "32px auto 12px"
      }}>
        اختر نوع الخدمة وابدأ مشروعك مع تجربة Apple الأصلية.
      </div>

      {/* كروت الخدمات */}
      <div style={{
        display: "grid",
        gridTemplateColumns: "repeat(4, 1fr)",
        gap: 38,
        maxWidth: 1050,
        margin: "35px auto 18px",
        justifyItems: "center"
      }}>
        {cards.map(c => (
          <button
            key={c.key}
            className={`ios-card${selected === c.key ? " active" : ""}`}
            onClick={() => setSelected(c.key)}
            style={{
              width: 148,
              minHeight: 122,
              background: "rgba(255,255,255,0.88)",
              border: selected === c.key
                ? "2.9px solid #6a70c8"
                : "1.5px solid #e2e7f7",
              borderRadius: 22,
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              boxShadow: selected === c.key
                ? "0 0 0 7px #a6b4fc25, 0 7px 30px #cad1fc28"
                : "0 2px 11px #cfd7fc26",
              fontWeight: 900,
              cursor: "pointer",
              transition: "all .23s cubic-bezier(.5,2.3,.4,1)",
              filter: selected === c.key
                ? "drop-shadow(0 8px 24px #8395fc42)"
                : "",
              backdropFilter: "blur(9px)",
              WebkitBackdropFilter: "blur(9px)"
            }}
          >
            <img
              src={c.icon}
              alt={c.label}
              style={{ width: 41, height: 41, marginBottom: 8 }}
            />
            <span style={{
              color: "#6a70c8",
              fontWeight: 900,
              fontSize: 15,
              marginTop: 2
            }}>
              {c.label}
            </span>
          </button>
        ))}
      </div>

      {/* نموذج الطلب */}
      <form onSubmit={handleSubmit} style={{
        background: "rgba(255,255,255,0.96)",
        borderRadius: 27,
        boxShadow: "0 5px 22px #d8dfff19, 0 1px 5px #b6c1ff11",
        maxWidth: 490,
        margin: "0 auto",
        padding: "35px 29px 20px",
        marginTop: 28,
        display: "flex",
        flexDirection: "column",
        gap: 19,
        alignItems: "center",
        border: "1.7px solid #e2e7f7",
        backdropFilter: "blur(13px)",
        WebkitBackdropFilter: "blur(13px)"
      }}>
        <div style={{
          display: "flex",
          alignItems: "center",
          gap: 12,
          marginBottom: 7
        }}>
          <img src={serviceIcon} alt="نوع الخدمة" style={{ width: 31, height: 31 }} />
          <h2 style={{
            color: "#6a70c8",
            fontWeight: 900,
            fontSize: 19
          }}>
            {serviceLabel}
          </h2>
        </div>
        <input
          type="text"
          placeholder="فكرة التطبيق أو اسم المشروع"
          value={idea}
          onChange={e => setIdea(e.target.value)}
          required
          style={{
            padding: "12px 15px",
            borderRadius: 13,
            border: "1.6px solid #6a70c838",
            fontSize: 17,
            width: "100%",
            background: "rgba(250,250,255,0.91)",
            boxShadow: "0 2px 9px #dbe4fa12", 
            outline: "none",
            marginBottom: 4
          }}
        />
        <select
          value={budget}
          onChange={e => setBudget(e.target.value)}
          required
          style={{
            padding: "10px 12px",
            borderRadius: 13,
            border: "1.5px solid #6a70c838",
            fontSize: 16,
            color: "#6a70c8",
            width: "100%",
            background: "rgba(250,250,255,0.95)",
            outline: "none"
          }}
        >
          <option value="">الميزانية المتوقعة</option>
          <option value="5000-10000">5000 - 10000 ريال</option>
          <option value="10000-20000">10000 - 20000 ريال</option>
          <option value="20000+">أكثر من 20000 ريال</option>
        </select>
        <input
          type="text"
          placeholder="الجمهور المستهدف (اختياري)"
          value={audience}
          onChange={e => setAudience(e.target.value)}
          style={{
            padding: "12px 15px",
            borderRadius: 13,
            border: "1.5px solid #6a70c838",
            fontSize: 16,
            width: "100%",
            background: "rgba(250,250,255,0.91)",
            boxShadow: "0 1px 6px #dbe4fa13",
            outline: "none"
          }}
        />
        <button type="submit" style={{
          marginTop: 8,
          background: "linear-gradient(94deg,#7b88f4 50%,#50c0fa 100%)",
          color: "#fff",
          fontWeight: 900,
          fontSize: 17,
          borderRadius: 12,
          border: "none",
          boxShadow: "0 5px 18px #7b88f438",
          padding: "13px 0",
          letterSpacing: 0.5,
          cursor: "pointer",
          transition: "background .17s",
          width: "100%"
        }}>
          أرسل الطلب 🚀
        </button>
      </form>

      {/* بطاقات التحفيز */}
      <div style={{
        display: "flex",
        justifyContent: "center",
        gap: 30,
        margin: "38px auto 0 auto",
        maxWidth: 960,
        flexWrap: "wrap"
      }}>
        {badges.map((b, i) => (
          <div key={i} style={{
            background: "rgba(255,255,255,0.77)",
            borderRadius: 19,
            minWidth: 205,
            maxWidth: 255,
            padding: "19px 18px 13px 17px",
            boxShadow: "0 7px 27px #a6b4fc26",
            border: "2.2px solid #e2e7f7",
            textAlign: "center",
            marginBottom: 11,
            backdropFilter: "blur(7.5px)",
            WebkitBackdropFilter: "blur(7.5px)"
          }}>
            <img src={b.icon} alt={b.title} style={{ width: 31, height: 31, marginBottom: 5 }} />
            <div style={{
              fontWeight: 900,
              fontSize: 15.8,
              margin: "7px 0",
              color: "#6a70c8"
            }}>
              {b.title}
            </div>
            <div style={{
              color: "#7a7fa4",
              fontSize: 13.3,
              fontWeight: 500
            }}>
              {b.desc}
            </div>
          </div>
        ))}
      </div>

      {/* شريط توثيق Apple */}
      <div style={{
        margin: "34px auto 0 auto",
        maxWidth: 520,
        padding: "13px 18px",
        background: "rgba(250,250,255,0.91)",
        border: "2.1px solid #b6c1ff99",
        borderRadius: 17,
        display: "flex",
        alignItems: "center",
        gap: 12,
        boxShadow: "0 3px 15px #a6b4fc1a",
        backdropFilter: "blur(6px)"
      }}>
        <img src={shieldIcon} alt="توثيق Apple" style={{ width: 28, height: 28 }} />
        <span style={{
          color: "#6a70c8",
          fontWeight: 900,
          fontSize: 14.5,
          letterSpacing: 0.7,
          display: "flex",
          alignItems: "center"
        }}>
          جميع الطلبات مصدّقة Apple
          <img src={checkIcon} alt="توثيق" style={{ height: 17, margin: "0 7px" }} />
        </span>
      </div>

      <style>
        {`
          .ios-card:hover,
          .ios-card.active {
            filter: drop-shadow(0 9px 30px #7b88f488) !important;
            z-index: 20 !important;
            background: #f5f7ff !important;
            border-color: #7b88f4 !important;
          }
        `}
      </style>
    </div>
  );
}
