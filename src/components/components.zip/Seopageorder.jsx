import React, { useState } from "react";
import { useLocation } from "react-router-dom";

import rocketIcon from "../assets/svg/seo-rocket.svg";
import shieldIcon from "../assets/svg/seo-shield.svg";
import awardIcon  from "../assets/svg/seo-award.svg";
import googleIcon from "../assets/svg/google.svg";
import chartIcon  from "../assets/svg/chart.svg";
import sparkIcon  from "../assets/svg/spark.svg";
import waveCloud  from "../assets/svg/wave-cloud.svg";
import stoneIcon  from "../assets/svg/stone.svg";



export default function SeoOrder() {
  const [site, setSite]         = useState("");
  const [goal, setGoal]         = useState("");
  const [keywords, setKeywords] = useState("");
  const [sending, setSending]   = useState(false);

  // نجيب site_type_id من الـ URL أو نستخدم الافتراضي (غيّره ليناسب جدولك)
  const location     = useLocation();
  const params       = new URLSearchParams(location.search);
  const siteTypeId   = parseInt(params.get("type"), 10) || 5; // استبدل 5 بالـ id الصحيح لـ SEO

  const goals = [
    { value: "keywords", label: "تصدر كلمات بحث معينة", icon: chartIcon },
    { value: "visits",   label: "زيادة زيارات الموقع",    icon: sparkIcon },
    { value: "speed",    label: "تسريع الموقع ورفع الأداء", icon: awardIcon },
    { value: "report",   label: "تقرير مفصل عن السيو",       icon: shieldIcon }
  ];

  const handleSubmit = async e => {
    e.preventDefault();
    setSending(true);

    let formatted = site.trim();
    if (!/^https?:\/\//i.test(formatted)) {
      formatted = `https://${formatted}`;
    }

    const user = JSON.parse(localStorage.getItem("user"));
    if (!user?.id) {
      alert("🔑 يجب تسجيل الدخول أولًا!");
      setSending(false);
      return;
    }

    try {
      const res = await fetch("http://localhost:5000/api/orders/create-seo", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          user_id:      user.id,
          site_type_id: 5,
          site_type_id: siteTypeId,
          site:         formatted,
          goal,
          keywords:     keywords || goal
        })
      });
      const data = await res.json();

      if (res.ok) {
        alert("✅ تم استلام طلب SEO بنجاح!");
        setSite("");
        setGoal("");
        setKeywords("");
      } else {
        alert(data.error || "❌ حدث خطأ أثناء الإرسال");
      }
    } catch {
      alert("⚠️ تعذر الاتصال بالخادم!");
    }

    setSending(false);
  };

  return (
    <div style={{
      minHeight: "100vh",
      background: "linear-gradient(120deg,#f8f8ff 70%,#e2e8fa 100%)",
      fontFamily: "Tajawal, Arial",
      paddingBottom: 90,
      direction: "rtl",
      overflowX: "hidden"
    }}>
      {/* Header */}
      <div style={{
        position: "relative",
        textAlign: "center",
        background: "linear-gradient(101deg,#a18fff 50%,#8fc5ff 110%)",
        padding: "60px 0 100px"
      }}>
        <img src={rocketIcon} alt="SEO Rocket" style={{ width: 70, filter: "drop-shadow(0 5px 22px #7c4dff33)" }} />
        <img src={waveCloud} alt="Cloud" style={{ position: "absolute", top: 0, left: 0, width: 60, opacity: 0.8 }} />
        <img src={waveCloud} alt="Cloud" style={{ position: "absolute", top: 10, right: 0, width: 70, opacity: 0.8 }} />
        <img src={stoneIcon} alt="Stone" style={{ position: "absolute", bottom: -10, left: 30, width: 35, opacity: 0.7 }} />
        <img src={stoneIcon} alt="Stone" style={{ position: "absolute", bottom: -10, right: 40, width: 30, opacity: 0.7 }} />

        <h1 style={{
          margin: 0,
          fontSize: "2.2rem",
          fontWeight: 900,
          color: "#fff",
          textShadow: "0 4px 18px #7c4dff33"
        }}>
          🚀 اطلب خدمة SEO — انطلق للصفحة الأولى!
        </h1>
        <p style={{ color: "#e8edff", fontSize: 18, fontWeight: 600 }}>
          تقارير سعودية، جودة Google، دعم احترافي… منصة تصدر حقيقية!
        </p>
      </div>

      {/* Form Section */}
      <section style={{
        maxWidth: 550,
        margin: "50px auto 60px",
        background: "#fff",
        borderRadius: 20,
        boxShadow: "0 12px 44px #a18fff17",
        border: "2px solid #e8e3ff",
        padding: "40px 30px",
        position: "relative",
        zIndex: 2
      }}>
        <div style={{ display: "flex", justifyContent: "center", gap: 20, marginBottom: 20 }}>
          {[googleIcon, shieldIcon, awardIcon].map((icon, i) =>
            <img key={i} src={icon} alt="" style={{ width: i === 0 ? 36 : 30 }} />
          )}
        </div>

        <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: 20 }}>
          {/* Site Input */}
          <label style={{ fontWeight: 900, color: "#7c4dff" }}>موقعك الإلكتروني:</label>
          <div style={{
            display: "flex", alignItems: "center",
            background: "#f8f7fd", borderRadius: 12, padding: "10px 14px"
          }}>
            <img src={googleIcon} alt="" style={{ width: 20, opacity: 0.7 }} />
            <input
              type="text"
              value={site}
              onChange={e => setSite(e.target.value)}
              placeholder="مثال: www.example.com"
              required
              style={{ flex: 1, border: "none", background: "none", outline: "none", fontWeight: 700 }}
            />
          </div>

          {/* Goal Selection */}
          <label style={{ fontWeight: 900, color: "#7c4dff" }}>هدفك الأساسي في السيو:</label>
          <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
            {goals.map(g => (
              <button
                key={g.value}
                type="button"
                onClick={() => setGoal(g.value)}
                style={{
                  display: "flex", alignItems: "center", gap: 6,
                  padding: "8px 12px", borderRadius: 8,
                  border: goal === g.value ? "2px solid #7c4dff" : "1px solid #ddd",
                  background: goal === g.value ? "#7c4dff" : "#f7f7fd",
                  color: goal === g.value ? "#fff" : "#555",
                  fontWeight: 700, cursor: "pointer"
                }}
              >
                <img src={g.icon} alt="" style={{ width: 16 }} />
                {g.label}
              </button>
            ))}
          </div>

          {/* Keywords Input */}
          {goal === "keywords" && (
            <>
              <label style={{ fontWeight: 900, color: "#7c4dff" }}>كلمات البحث المستهدفة:</label>
              <input
                type="text"
                value={keywords}
                onChange={e => setKeywords(e.target.value)}
                placeholder="مثال: تصميم مواقع، استضافة سعودية..."
                required
                style={{
                  padding: "10px",
                  borderRadius: 8,
                  border: "1px solid #ddd",
                  fontWeight: 700
                }}
              />
            </>
          )}

          {/* Submit Button */}
          <button
            type="submit"
            disabled={sending || !site || !goal || (goal === "keywords" && !keywords)}
            style={{
              padding: "12px 0",
              borderRadius: 12,
              background: sending ? "#ccc" : "#21c692",
              color: "#fff",
              fontWeight: 900,
              cursor: sending ? "not-allowed" : "pointer"
            }}
          >
            {sending ? "🚀 جاري إرسال الطلب..." : "🚀 انطلق للصفحة الأولى!"}
          </button>
        </form>

        {/* Key Points */}
        <ul style={{
          marginTop: 30,
          color: "#21c692",
          fontWeight: 700,
          listStyle: "inside"
        }}>
          <li>كل الطلبات بتقارير وفواتير سعودية رسمية</li>
          <li>خدمة دعم وتعديل فوري مجانًا</li>
        </ul>
      </section>

      {/* Why Choose Us */}
      <section style={{ textAlign: "center", padding: "40px 20px" }}>
        <h2 style={{
          fontSize: 24, fontWeight: 900, color: "#7c4dff", marginBottom: 20
        }}>
          لماذا منصة منجز أفضل خيار SEO؟
        </h2>
        <div style={{
          display: "flex", gap: 20, flexWrap: "wrap", justifyContent: "center"
        }}>
          {[
            { icon: rocketIcon, title: "تقنيات Google Rocket", desc: "أسرع صعود بأقل تكلفة" },
            { icon: awardIcon,  title: "تقارير وفواتير سعودية", desc: "توثق كل النتائج رسمياً" },
            { icon: shieldIcon, title: "أمان وحماية متكاملة", desc: "حماية بياناتك وتجربتك" }
          ].map((item, i) => (
            <div key={i} style={{
              flex: "0 0 220px", background: "#fff", borderRadius: 12,
              padding: 20, boxShadow: "0 4px 16px #ddd"
            }}>
              <img src={item.icon} alt="" style={{ width: 40 }} />
              <h3 style={{
                fontSize: 18, fontWeight: 900, color: "#333", margin: "10px 0"
              }}>{item.title}</h3>
              <p style={{ color: "#555", fontSize: 14 }}>{item.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Footer */}
      <footer style={{
        textAlign: "center",
        padding: 20,
        color: "#7c4dff",
        fontWeight: 700
      }}>
        🚀 SEO Rocket | powered by منجز
      </footer>
    </div>
  );
}
